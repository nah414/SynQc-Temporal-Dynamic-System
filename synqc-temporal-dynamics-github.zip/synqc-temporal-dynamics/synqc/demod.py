
import numpy as np

def lockin_demod(signal, ref_freq_hz, dt_s):
    """Boxcar low-pass of I/Q demod with reference at `ref_freq_hz`."""
    n = len(signal)
    t = np.arange(n)*dt_s
    refc = np.cos(2*np.pi*ref_freq_hz*t)
    refs = np.sin(2*np.pi*ref_freq_hz*t)
    i_raw = signal * refc
    q_raw = signal * refs
    ideal = int(0.01/dt_s) if dt_s > 0 else n
    win = max(1, min(ideal, max(1, n//4)))
    kernel = np.ones(win, dtype=float)/win
    i_lp = np.convolve(i_raw, kernel, mode="same")
    q_lp = np.convolve(q_raw, kernel, mode="same")
    return i_lp, q_lp
