
import numpy as np
from .probes import drive, probe, add_readout_latency
from .demod import lockin_demod

class DPDResult:
    def __init__(self, t, signal, i_lp, q_lp, phase, amp, states, probe_mask):
        self.t = t
        self.signal = signal
        self.i_lp = i_lp
        self.q_lp = q_lp
        self.phase = phase
        self.amp = amp
        self.states = states
        self.probe_mask = probe_mask

def run_dpd_sequence(hw, detuning_hz, omega_hz, d1_s, probe_s, d2_s,
                     readout_axis="z", dt_s=1e-7, ref_freq_hz=None, shots=200, meas_noise=0.02):
    """Fixed-length, preallocated timeline (no shape mismatches)."""
    n1 = int(np.ceil(d1_s/dt_s))
    nP = int(np.ceil(probe_s/dt_s))
    n2 = int(np.ceil(d2_s/dt_s))
    nT = max(1, n1 + nP + n2)

    # Timebase
    t = dt_s * (np.arange(nT) + 1)
    meas = np.full(nT, np.nan, dtype=float)
    states = []

    # Reference for demod
    if ref_freq_hz is None:
        ref_freq_hz = detuning_hz if abs(detuning_hz) > 1.0 else 1.0e5

    # Evolve state
    state = (0.0, 0.0, 1.0)

    # Drive 1
    for _ in range(n1):
        state = drive(state, detuning_hz, omega_hz, dt_s, hw)
        states.append(state)

    # Probe
    startP = n1
    endP = min(n1 + nP, nT)
    for k in range(startP, endP):
        meas[k] = probe(state, axis=readout_axis, shots=shots, meas_noise=meas_noise)
        states.append(state)

    # Drive 2
    for _ in range(endP, nT):
        state = drive(state, detuning_hz, omega_hz, dt_s, hw)
        states.append(state)

    # Build signal and apply latency preserving length
    signal = meas.copy()
    signal = add_readout_latency(signal, hw.probe_latency, dt_s)

    # Demodulation over the full vector with zeros outside probe
    probe_mask = ~np.isnan(meas)
    demod_input = np.where(probe_mask, np.nan_to_num(signal, nan=0.0), 0.0)
    i_lp, q_lp = lockin_demod(demod_input, ref_freq_hz, dt_s)

    if np.any(probe_mask):
        i_mean = float(np.mean(i_lp[probe_mask]))
        q_mean = float(np.mean(q_lp[probe_mask]))
        phase = float(np.arctan2(q_mean, i_mean))
        amp = float(np.hypot(i_mean, q_mean))
    else:
        phase = 0.0
        amp = 0.0

    return DPDResult(t, signal, i_lp, q_lp, phase, amp, states, probe_mask)
