
import numpy as np
from .mathkern import bloch_update, t1_t2_relax, measurement_signal

rng = np.random.default_rng(1234)

def drive(state, detuning_hz, omega_hz, duration_s, hw):
    """One integration step with a constant drive (Hz→rad/s)."""
    det = 2*np.pi*detuning_hz
    omg = 2*np.pi*omega_hz
    x, y, z = bloch_update(state, det, omg, duration_s)
    x, y, z = t1_t2_relax((x, y, z), duration_s, hw.t1, hw.t2)
    return (x, y, z)

def probe(state, axis="z", shots=200, meas_noise=0.02):
    """Return a noisy readout of the expectation along `axis`."""
    ideal = measurement_signal(state, axis=axis)
    noise = rng.normal(0.0, meas_noise/np.sqrt(max(1, shots)))
    return float(ideal + noise)

def add_readout_latency(samples, latency_s, dt_s):
    """Shift samples by integer bins of latency; preserve length."""
    n = len(samples)
    bins = int(round(latency_s / dt_s))
    if bins <= 0 or bins >= n:
        return samples
    out = np.empty_like(samples)
    out[:bins] = 0.0
    out[bins:] = samples[:-bins]
    return out
