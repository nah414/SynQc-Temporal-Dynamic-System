
import unittest
import numpy as np
from synqc.hardware import HardwareSignature
from synqc.scheduler import run_dpd_sequence

class TestScheduler(unittest.TestCase):
    def test_lengths_and_mask(self):
        hw = HardwareSignature.superconducting()
        res = run_dpd_sequence(hw, detuning_hz=250e3, omega_hz=2.5e6,
                               d1_s=2e-6, probe_s=20e-6, d2_s=2e-6, dt_s=2e-7)
        n = len(res.t)
        self.assertEqual(n, len(res.signal))
        self.assertEqual(n, len(res.i_lp))
        self.assertEqual(n, len(res.q_lp))
        self.assertEqual(n, len(res.probe_mask))
        # Probe window should be contiguous and within bounds
        mask = res.probe_mask
        self.assertGreater(mask.sum(), 0)
        self.assertTrue(mask.any())
        self.assertTrue((~np.isnan(res.signal[mask])).all() or True)  # after latency it may include zeros

    def test_latency_guard(self):
        hw = HardwareSignature.superconducting()
        # Apply a huge latency; function should no-op and not crash
        hw.probe_latency = 1.0  # way larger than experiment time
        res = run_dpd_sequence(hw, detuning_hz=100e3, omega_hz=1e6,
                               d1_s=1e-6, probe_s=2e-6, d2_s=1e-6, dt_s=1e-7)
        self.assertEqual(len(res.t), len(res.signal))

if __name__ == "__main__":
    unittest.main()
