
# Changelog

## 0.2.0 — Fixed
- Deterministic scheduler with preallocated timeline (no shape mismatches).
- Latency applied after full timeline build; length-preserving shift.
- Demod low-pass window now capped.
- Added unit tests and CI workflow.
- Layman's README and packaging via `pyproject.toml`.
