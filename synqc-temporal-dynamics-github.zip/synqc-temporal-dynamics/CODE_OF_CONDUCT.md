
# Code of Conduct

Be kind, be constructive, respect each other. Disagreements happen; harassment is not tolerated.
