
import numpy as np
from .probes import drive, probe, add_readout_latency
from .demod import lockin_demod

class DPDResult:
    def __init__(self, t, signal, i_lp, q_lp, phase, amp, states):
        self.t = t
        self.signal = signal
        self.i_lp = i_lp
        self.q_lp = q_lp
        self.phase = phase
        self.amp = amp
        self.states = states

def run_dpd_sequence(hw, detuning_hz, omega_hz, d1_s, probe_s, d2_s,
                     readout_axis="z", dt_s=1e-7, ref_freq_hz=None, shots=200, meas_noise=0.02):
    if ref_freq_hz is None:
        ref_freq_hz = detuning_hz if abs(detuning_hz) > 1.0 else 1.0e5

    state = (0.0, 0.0, 1.0)
    times = []
    meas = []
    states = []

    # Drive 1
    n1 = int(np.ceil(d1_s/dt_s))
    for _ in range(n1):
        state = drive(state, detuning_hz, omega_hz, dt_s, hw)
        times.append(dt_s if not times else times[-1]+dt_s)
        meas.append(np.nan)
        states.append(state)

    # Probe
    nP = int(np.ceil(probe_s/dt_s))
    for _ in range(nP):
        m = probe(state, axis=readout_axis, shots=shots, meas_noise=meas_noise)
        times.append(times[-1]+dt_s if times else dt_s)
        meas.append(m)
        states.append(state)

    # Drive 2
    n2 = int(np.ceil(d2_s/dt_s))
    for _ in range(n2):
        state = drive(state, detuning_hz, omega_hz, dt_s, hw)
        times.append(times[-1]+dt_s)
        meas.append(np.nan)
        states.append(state)

    t = np.array(times, dtype=float)
    signal = np.array(meas, dtype=float)

    # Apply readout latency across full signal
    # latency disabled for preview
        # signal = add_readout_latency(signal, hw.probe_latency, dt_s)

    # Demodulate only over probe region
    meas_arr = np.array(meas, dtype=float)
    probe_mask = ~np.isnan(meas_arr)
    probe_signal = np.where(probe_mask, signal, 0.0)
    i_lp, q_lp = lockin_demod(probe_signal, ref_freq_hz, dt_s)

    if np.any(probe_mask):
        i_mean = np.mean(i_lp[probe_mask])
        q_mean = np.mean(q_lp[probe_mask])
        phase = np.arctan2(q_mean, i_mean)
        amp = np.sqrt(i_mean**2 + q_mean**2)
    else:
        phase = 0.0
        amp = 0.0

    return DPDResult(t, signal, i_lp, q_lp, phase, amp, states)
