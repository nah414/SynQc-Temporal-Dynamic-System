
import numpy as np

def rabi_phase(detuning, omega, duration):
    omega_eff = np.sqrt(omega**2 + detuning**2)
    return omega_eff * duration

def bloch_update(state, detuning, omega, duration):
    x, y, z = state
    omega_eff = np.sqrt(omega**2 + detuning**2)
    if omega_eff == 0.0 or duration == 0.0:
        return x, y, z

    nx, ny, nz = omega/omega_eff, 0.0, detuning/omega_eff
    theta = omega_eff * duration

    r = np.array([x, y, z], dtype=float)
    n = np.array([nx, ny, nz], dtype=float)
    r_par = np.dot(r, n) * n
    r_perp = r - r_par
    r_rot = r_par + r_perp*np.cos(theta) + np.cross(n, r)*np.sin(theta)
    return tuple(r_rot.tolist())

def t1_t2_relax(state, tstep, t1, t2):
    x, y, z = state
    if t2 > 0:
        x *= np.exp(-tstep / t2)
        y *= np.exp(-tstep / t2)
    if t1 > 0:
        z = 1.0 - (1.0 - z) * np.exp(-tstep / t1)
    return x, y, z

def measurement_signal(state, axis="z"):
    x, y, z = state
    if axis == "x":
        return x
    if axis == "y":
        return y
    return z
