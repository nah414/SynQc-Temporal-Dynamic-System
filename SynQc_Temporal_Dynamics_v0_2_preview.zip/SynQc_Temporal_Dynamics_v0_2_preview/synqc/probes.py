
import numpy as np
from .mathkern import bloch_update, t1_t2_relax, measurement_signal

rng = np.random.default_rng(1234)

def drive(state, detuning_hz, omega_hz, duration_s, hw):
    det = 2*np.pi*detuning_hz
    omg = 2*np.pi*omega_hz
    x,y,z = bloch_update(state, det, omg, duration_s)
    x,y,z = t1_t2_relax((x,y,z), duration_s, hw.t1, hw.t2)
    return (x,y,z)

def probe(state, axis="z", shots=200, meas_noise=0.02):
    ideal = measurement_signal(state, axis=axis)
    noise = rng.normal(0.0, meas_noise/np.sqrt(max(1,shots)))
    return ideal + noise

def add_readout_latency(samples, latency_s, dt_s):
    bins = int(round(latency_s / dt_s))
    if bins <= 0:
        return samples
    padded = np.concatenate([np.zeros(bins), samples[:-bins]])
    return padded
