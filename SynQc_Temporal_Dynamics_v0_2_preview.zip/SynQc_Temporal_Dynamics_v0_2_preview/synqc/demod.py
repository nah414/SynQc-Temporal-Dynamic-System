
import numpy as np

def lockin_demod(signal, ref_freq_hz, dt_s):
    n = len(signal)
    t = np.arange(n)*dt_s
    refc = np.cos(2*np.pi*ref_freq_hz*t)
    refs = np.sin(2*np.pi*ref_freq_hz*t)
    i_raw = signal * refc
    q_raw = signal * refs
    win = max(1, int(0.01/dt_s))
    kernel = np.ones(win)/win
    i_lp = np.convolve(i_raw, kernel, mode="same")
    q_lp = np.convolve(q_raw, kernel, mode="same")
    return i_lp, q_lp

def estimate_phase(i_val, q_val):
    return np.arctan2(q_val, i_val)

def estimate_amplitude(i_val, q_val):
    return np.sqrt(i_val**2 + q_val**2)
