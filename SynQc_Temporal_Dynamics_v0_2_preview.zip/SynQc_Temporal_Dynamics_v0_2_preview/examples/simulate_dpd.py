
import numpy as np
import matplotlib.pyplot as plt
from synqc.hardware import HardwareSignature
from synqc.scheduler import run_dpd_sequence
from synqc.adapt import ScalarKalman

hw = HardwareSignature.superconducting()
detuning_true_hz = 250e3
omega_hz = 2.5e6

d1_s = 2.0e-6
probe_s = 20.0e-6
d2_s = 2.0e-6
dt_s = 2.0e-7

kf = ScalarKalman(x0=0.0, p0=1e12, q=1e7, r=1e6)

est_hist = []
phase_hist = []
for _ in range(25):
    detuning_cmd = -kf.x
    res = run_dpd_sequence(hw, detuning_cmd + detuning_true_hz, omega_hz,
                           d1_s, probe_s, d2_s, readout_axis="z", dt_s=dt_s)

    z_meas = res.phase * 1.0e5  # simple scale to bring into Hz-ish units
    kf.predict()
    x, p, k, innov = kf.update(z_meas, H=1.0)

    est_hist.append(x)
    phase_hist.append(res.phase)

# Plots
fig1 = plt.figure()
plt.title("Adaptive detuning estimate")
plt.plot(est_hist, label="Kalman estimate (Hz)")
plt.axhline(0.0, linestyle="--")
plt.xlabel("Iteration")
plt.ylabel("Detuning estimate (Hz)")
plt.legend()
plt.tight_layout()

fig2 = plt.figure()
plt.title("Probe demodulated phase (proxy)")
plt.plot(phase_hist, label="Measured phase (rad)")
plt.xlabel("Iteration")
plt.ylabel("Phase (rad)")
plt.legend()
plt.tight_layout()

res0 = run_dpd_sequence(hw, detuning_true_hz, omega_hz, d1_s, probe_s, d2_s, dt_s=dt_s)
fig3 = plt.figure()
plt.title("DPD: raw probe window (with NaNs elsewhere)")
plt.plot(res0.t, res0.signal, label="Measured (probe window)")
plt.xlabel("Time (s)")
plt.ylabel("Signal (arb)")
plt.legend()
plt.tight_layout()

plt.show()
