
# SynQc: Temporal Dynamics Series — v0.2 (Preview)

Demonstrates a Drive-Probe-Drive (DPD) control loop with:
- Hardware signatures (superconducting, ion, neutral atom, photonic)
- Minimal math kernel (Bloch evolution + T1/T2)
- Probe + lock-in demodulation
- Scalar Kalman tracking of residual detuning
- Runnable example producing traces + an adaptive estimate trajectory

## Quickstart (Windows-friendly)

1. Create a virtual environment (Python 3.10+).
2. pip install numpy matplotlib
3. python examples/simulate_dpd.py

## Files
- synqc/mathkern.py
- synqc/hardware.py
- synqc/probes.py
- synqc/demod.py
- synqc/adapt.py
- synqc/scheduler.py
- examples/simulate_dpd.py
